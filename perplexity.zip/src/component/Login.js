import React from 'react'
import './Login.css'

const Login = () => {
  return (
      <>
      <h1>This is Login page</h1>
      </>
  )
}

export default Login
